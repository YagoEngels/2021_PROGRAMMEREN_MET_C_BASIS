﻿using System;

namespace _2021_c_basis_opdrachten_8
{
    class Program
    {
        //int keuze 
        static int keuze = 0;
        static Simbox simbox = new Simbox();

        static void Main(string[] args)
        {
            menu();

        }
        static void menu()
        {
            Console.WriteLine("********************************************");
            Console.WriteLine("****************** SIMBOX ******************");
            Console.WriteLine("********************************************");
            Console.WriteLine("********************************************");
            Console.WriteLine("** 1 : Simkaart gegevens ingeven ***********");
            Console.WriteLine("** 2 : Overzicht SIM kaart gegevenbs *******");
            Console.WriteLine("** 3 : Bellen ******************************");
            Console.WriteLine("** 4 : STOP ********************************");

            keuze = int.Parse(Console.ReadLine());

            Simkaart simkaart = new Simkaart();

            switch (keuze)
            {
                case 1:
                    if (simbox.getAantalSimKaarten() != 3)
                    {
                        Console.Write("geef het telefoonnummer van de simkaart in:   ");
                        string s = Console.ReadLine();
                        Console.WriteLine("");
                        simbox.addSimKaart(s);
                    }
                    else
                    {
                        Console.WriteLine("Maximaal aantal SIM kaarten geinstalleerd \n");
                    }
                    menu();
                    break;

                case 2:
                    //simbox.getSim1();
                    simbox.getOverzicht();
                    menu();
                    break;

                case 3:
                    switch (simbox.getAantalSimKaarten())
                    {
                        case 0:
                            Console.WriteLine("je moet eerst een simkaart aanmaken");
                            menu();
                            break;
                        case 1:
                            Console.WriteLine("Kies vanop welk nummer je wilt bellen");
                            Console.WriteLine("1:" + simbox.getSim1TelefoonNummer());
                            int i = int.Parse(Console.ReadLine());
                            Console.WriteLine("geef het nummer waarnaartoe je wilt bellen");
                            string n = Console.ReadLine();
                            simbox.bellen(i, n);
                            menu();
                            break;
                        case 2:
                            Console.WriteLine("Kies vanop welk nummer je wilt bellen");
                            Console.WriteLine("1:" + simbox.getSim1TelefoonNummer());
                            Console.WriteLine("2:" + simbox.getSim2TelefoonNummer());
                            int ia = int.Parse(Console.ReadLine());
                            Console.WriteLine("geef het nummer waarnaartoe je wilt bellen");
                            string na = Console.ReadLine();
                            simbox.bellen(ia, na);
                            menu();
                            break;
                        case 3:
                            Console.WriteLine("Kies vanop welk nummer je wilt bellen");
                            Console.WriteLine("1:" + simbox.getSim1TelefoonNummer());
                            Console.WriteLine("2:" + simbox.getSim2TelefoonNummer());
                            Console.WriteLine("3:" + simbox.getSim3TelefoonNummer());
                            int ib = int.Parse(Console.ReadLine());
                            Console.WriteLine("geef het nummer waarnaartoe je wilt bellen");
                            string nb = Console.ReadLine();
                            simbox.bellen(ib, nb);
                            menu();
                            break;
                    }
                    break;

                case 4:
                    Console.WriteLine("********************************************");
                    Console.WriteLine("***************--- by by ---****************");
                    Console.WriteLine("********************************************");
                    break;

            }
        }
    }
}
