﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_8
{

    class Simkaart
    {
        private string telefoonNummer;
        private DateTime creatieDatum;
        private int aantalOproepen;
        private string nummerLaatsteOproep;

        public Simkaart()
        {
            telefoonNummer = string.Empty;
            creatieDatum = DateTime.Now;
            aantalOproepen = 0;
            nummerLaatsteOproep = string.Empty;
        }

        public void setTelefoonNummer(string nummer)
        {
            telefoonNummer = nummer;
        }

        public string getTelefoonNummer()
        {
            return telefoonNummer;
        }

        public DateTime getCreatieDatum()
        {
            return creatieDatum;
        }

        public string getZin()
        {
            string uit = "\tTelefoonnummer: +32 " + telefoonNummer + "\n \tCreatiedatum datum: " + creatieDatum.ToString() + "\n \tAantal oproepen: " + getAantalOproepen() + "\n \tLaatste nummer: " + getLaatsteNummer();
            return uit;
        }

        public int getAantalOproepen()
        {
            return aantalOproepen;
        }

        public void addAantalOproepen()
        {
            aantalOproepen++;
        }

        public string getLaatsteNummer()
        {
            return nummerLaatsteOproep;
        }

        public void setLaatsteNummer(string n)
        {
            if(n.Length != 0)
            {
                nummerLaatsteOproep = n;
            }
        }

        public void bel(string n)
        {
            if(n.Length != 0)
            {
                addAantalOproepen();
                setLaatsteNummer(n);
            }
        }
    }
}
