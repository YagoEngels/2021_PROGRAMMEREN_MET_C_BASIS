﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_8
{
    class Simbox
    {
        private Simkaart simkaart1;
        private Simkaart simkaart2;
        private Simkaart simkaart3;
        private int aantalSimKaarten;


        public Simbox()
        {

        }

        public void addSimKaart(string s)
        {
            if (s.Length != 0)
            {
                if (simkaart1 == null)
                {
                    simkaart1 = new Simkaart();
                    simkaart1.setTelefoonNummer(s);
                }
                else
                {
                    if (simkaart2 == null)
                    {
                        simkaart2 = new Simkaart();
                        simkaart2.setTelefoonNummer(s);
                    }
                    else
                    {
                        if (simkaart3 == null)
                        {
                            simkaart3 = new Simkaart();
                            simkaart3.setTelefoonNummer(s);
                        }
                    }
                }
            }
        }

        public void getOverzicht()
        {
            if (simkaart1 != null && simkaart2 != null && simkaart3 != null)
            {
                Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:" + "\n");
                Console.WriteLine("SIM kaart 1 - \n" + simkaart1.getZin() + "\n");
                Console.WriteLine("SIM kaart 2 - \n" + simkaart2.getZin() + "\n");
                Console.WriteLine("SIM kaart 3 - \n" + simkaart3.getZin() + "\n");
            }
            else
            {
                if (simkaart1 != null && simkaart2 != null && simkaart3 == null)
                {
                    Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:" + "\n");
                    Console.WriteLine("SIM kaart 1 - \n" + simkaart1.getZin() + "\n");
                    Console.WriteLine("SIM kaart 2 - \n" + simkaart2.getZin() + "\n");
                }
                else
                {
                    if (simkaart1 != null && simkaart2 == null && simkaart3 == null)
                    {
                        Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:" + "\n");
                        Console.WriteLine("SIM kaart 1 - \n" + simkaart1.getZin() + "\n");
                    }
                    else
                    {
                        Console.WriteLine("er is nog geen nummer ingegven");
                    }
                }
            }
        }

        public void getSim1()
        {
            Console.WriteLine(simkaart1.getZin());
            Console.WriteLine(simkaart2.getZin());
            Console.WriteLine(simkaart3.getZin());
        }

        public int getAantalSimKaarten()
        {
            int uit = 0;
            if (simkaart1 == null)
            {
                uit = 0;
            }
            else
            {
                if (simkaart1 != null && simkaart2 == null && simkaart3 == null)
                {
                    uit = 1;
                }
                else
                {
                    if (simkaart1 != null && simkaart2 != null && simkaart3 == null)
                    {
                        uit = 2;
                    }
                    else
                    {
                        if (simkaart1 != null && simkaart2 != null && simkaart3 != null)
                        {
                            uit = 3;
                        }
                    }
                }
            }
            return uit;
        }

        public string getSim1TelefoonNummer()
        {
            return simkaart1.getTelefoonNummer();
        }
        public string getSim2TelefoonNummer()
        {
            return simkaart2.getTelefoonNummer();
        }
        public string getSim3TelefoonNummer()
        {
            return simkaart3.getTelefoonNummer();
        }

        public void bellen(int i, string n)
        {
            switch (i)
            {
                case 1:
                    simkaart1.bel(n);
                    break;
                case 2:
                    simkaart2.bel(n);
                    break;
                case 3:
                    simkaart3.bel(n);
                    break;
            }
        }
    }
}
