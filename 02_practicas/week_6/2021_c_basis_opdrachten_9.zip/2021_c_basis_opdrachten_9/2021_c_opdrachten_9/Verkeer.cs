﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_opdrachten_9
{
    class Verkeer
    {
        Random random = new Random();

        public Verkeer()
        {
        }

        public void Rit(Auto a)
        {
            a.teller += random.Next(0,2001);
            if(random.Next(5) == 1)
            {
                a.schade += (random.NextDouble() * 1500) + 500;
            }
        }
    }
}
