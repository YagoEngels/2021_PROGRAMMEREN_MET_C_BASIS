﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_opdrachten_9
{
    class Auto
    {
        private string Nummerplaat;
        private int Teller;
        private double Schade;



        public Auto(string n)
        {
            nummerplaat = n;
            teller = 0;
            schade = 0;
        }

        public string nummerplaat
        {
            get
            {
                return Nummerplaat;
            }
            set
            {
                if(value.Length != 0)
                {
                    Nummerplaat = value;
                }
                else
                {
                    Console.WriteLine("er is iets mis gegaan met de nummerplaat");
                }
            }
        }

        public int teller
        {
            get
            {
                return Teller;
            }
            set
            {
                if(value > 0)
                {
                    Teller = value;
                }
                else
                {
                    Teller = 0;
                }
            }
        }

        public double schade
        {

            get
            {
                return Schade;
            }
            set
            {
                Schade = value;
            }
        }



        public string GeefOmschrijving()
        {
            string uit = "";
            uit += "Wagen info: \n - Nummerplaat: " + Nummerplaat.ToString() + " \n - Teller: " + Teller + " \n - Schade: " + Schade;
            return uit;
        }
    }
}

