﻿using System;

namespace _2021_c_opdrachten_9
{
    class Program
    {

        //int keuze 
        static int keuze = 0;
        static Auto a;
        static Verkeer verkeer;
        static Garage garage;

        static void Main(string[] args)
        {
            Console.Write("Geef de gegevens van je wagen in \n  - Nummerplaat: ");
            string plaat = Console.ReadLine();
            a = new Auto(plaat);
            verkeer = new Verkeer();
            garage = new Garage();

            menu();
        }

        static void menu()
        {
            Console.WriteLine("\n \n---------");
            Console.WriteLine("Keuzemenu");
            Console.WriteLine("---------");
            Console.WriteLine(" 1 : Voer een rit uit");
            Console.WriteLine(" 2 : Repareer wagen");
            Console.WriteLine(" 3 : Wagen info");
            Console.WriteLine(" 4 : STOP programma");

            keuze = int.Parse(Console.ReadLine());

            switch (keuze)
            {
                case 1:
                    verkeer.Rit(a);
                    menu();
                    break;

                case 2:
                    Console.WriteLine("De schade aan de wage werd gerepareed. Totale reparatiekost = " + garage.RepareerAuto(a));
                    Console.WriteLine(a.GeefOmschrijving());
                    menu();
                    break;

                case 3:
                    Console.WriteLine(a.GeefOmschrijving());
                    menu();
                    break;

                case 4:
                    Console.WriteLine("bye bye");
                    break;

            }
        }
    }
}
