﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_opdrachten_9
{
    class Garage
    {
        public Garage()
        {

        }

        public double RepareerAuto(Auto a)
        {
            double uit = 0;
            if(a.schade != 0)
            {
                uit = a.schade;
                a.schade = 0;
            }
            return uit;
        }
    }
}
