﻿using System;

namespace _2021_c_basis_opdrachten_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Dit is mijn tweede C# programma!!");
        }
    }
}
