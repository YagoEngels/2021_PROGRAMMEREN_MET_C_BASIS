﻿using System;

namespace _2021_c_basis_opdrachten_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gelieve een design karakter te kiezen (vb *, #, //....");
            string karakter = Console.ReadLine();
            Console.Write("Gelieve je coordinaten in te geven : ");
            Console.ReadLine();
            Console.Write("voornaam : ");
            string voornaam = Console.ReadLine();
            Console.Write("familienaam : ");
            string familienaam = Console.ReadLine();
            Console.Write("adress : ");
            string adress = Console.ReadLine();
            Console.Write("posstcode : ");
            string postcode = Console.ReadLine();
            Console.Write("plaats : ");
            string plaats = Console.ReadLine();

            Console.WriteLine("\n");

            for (int i = 0; i < 30; i++)
            {
                Console.Write(karakter);
            }
            Console.WriteLine("\n" + karakter + "\t Voornaam \t : " + voornaam);
            Console.WriteLine(karakter + "\t familienaam \t : " + familienaam);
            Console.WriteLine(karakter + "\t adres \t \t : " + adress);
            Console.WriteLine(karakter + "\t postcode \t : " + postcode);
            Console.WriteLine(karakter + "\t plaats \t : " + plaats);

            for (int i = 0; i < 30; i++)
            {
                Console.Write(karakter);
            }
        }
    }
}
