﻿using System;

namespace _2021_c_basis_opdrachten_4
{
    class Program
    {
        static void Main(string[] args)
        {

            double lengte;
            double breedte;
            double kg;
            double opp;
            double uiteindelijkzaad;

            Console.WriteLine("\n Geef volgende gegevens in : ");
            Console.Write("Lengte veld:\t \t \t");
            lengte = double.Parse(Console.ReadLine());
            Console.Write("Breedte veld:\t \t \t");
            breedte= double.Parse(Console.ReadLine());
            Console.Write("Aantal kg zaad per m2:\t \t");
            kg= double.Parse(Console.ReadLine());

            opp = lengte * breedte;
            Console.WriteLine("\nDe oppervlakte van het veld is:\t" + opp);

            uiteindelijkzaad = kg * opp;
            Console.WriteLine("Het aantal kg zaad nodig is:\t" + uiteindelijkzaad);

        }
    }
}
