﻿using System;

namespace Ucll.Csb.Pract.Variabelen
{
    class Program
    {
        static void Main(string[] args)
        {
            /// Enkele wisselkoers voorbeelden
            /// GBP (Britse pond) - 1,17
            /// USD (US dollar) - 0,86
            /// JPY (Japanse Yen) - 0,0077
            /// RUB (Rusische roebel) - 0,012
            /// 

            double rate = 0;
            double amountInEuro = 0;
            string currency = string.Empty;
            double amountInCurrency = 0;

            Console.WriteLine("Gelieve de volgende gegevens in te geven: ");
            Console.Write("\t- Naam van de gewenste munt: ");
            currency = Console.ReadLine();
            Console.Write("\t- Wisselkoers van de gewenste munt: ");
            rate = double.Parse(Console.ReadLine());
            Console.Write("\t- Om te zetten bedrag:");
            amountInEuro = double.Parse(Console.ReadLine());

            amountInCurrency = amountInEuro * rate;
            Console.WriteLine("Het bedrag in de gewenste munt is: " + amountInCurrency + " " +  currency);
        }
    }
}
