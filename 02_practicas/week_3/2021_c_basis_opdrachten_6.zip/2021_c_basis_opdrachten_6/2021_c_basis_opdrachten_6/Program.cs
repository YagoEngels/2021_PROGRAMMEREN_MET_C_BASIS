﻿using System;
using System.Collections;

namespace _2021_c_basis_opdrachten_6
{
    class Program
    {
        public static void Main(string[] args)
        {
            bool opernieuw = true;
            while(opernieuw == true)
            {
                ArrayList myAL = new ArrayList();

                //de beginzin + de cijfercodes
                Console.WriteLine("Gelieve een reeks positieve gehele getallen in te geven. Negatief om te stoppen.\n");
                Console.Write("<1>");
                myAL.Add(Console.ReadLine());
                while (int.Parse((string)myAL[^1]) > 0)
                {
                    Console.Write("<" + (myAL.Count + 1) + ">");
                    myAL.Add(Console.ReadLine());
                }

                // maxima berekening
                if (int.Parse((string)myAL[0]) > 0)
                {
                    int max = int.Parse((string)myAL[0]);
                    for (int i = 1; i < myAL.Count; i++)
                    {
                        if (max < int.Parse((string)myAL[i]))
                        {
                            max = int.Parse((string)myAL[i]);
                        }
                    }
                    Console.WriteLine("Het maximum van de ingegeven reeks is : " + max);
                }
                else
                {
                    Console.WriteLine("Het gemiddelde en maximum kan niet bepaald worden, er werden geen getallen ingegeven.");
                }

                // gemiddelde berekening
                if (int.Parse((string)myAL[0]) > 0)
                {
                    int gem = int.Parse((string)myAL[0]);
                    for (int i = 1; i < myAL.Count; i++)
                    {
                        if (i != myAL.Count - 1)
                        {
                            gem += int.Parse((string)myAL[i]);
                        }
                    }
                    gem /= (myAL.Count - 1);

                    Console.WriteLine("Het gemidelde van de ingegeven reeks is : " + gem);
                }


                // vraag stellen of dit alles opernieuw gedaan moet worden 
                Console.Write("Opnieuw het gemiddelde en maximum bepalen? <j/n> : ");
                string a = Console.ReadLine();
                if (a.Equals("j"))
                {
                    opernieuw = true;
                } else
                {
                    opernieuw = false;
                    Console.Write("BY BY");
                }
            }
        }
    }
}
