﻿using System;

namespace _2021_c_basis_opdrachten_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //variablelen aanmaken
            string maateenheid;
            double aantal;
            double uitkomst;

            //vragen achter de maateinheid
            Console.Write("Geef mij maateenheid waarin je wilt veranderen , je hebt de keuze tussen cm en inch : ");
            maateenheid = Console.ReadLine();

            //vragen achter de hoeveelheid
            Console.Write("Geef mij aantal die je wilt converteren : ");
            aantal = double.Parse(Console.ReadLine());

            if(maateenheid.Equals("cm") || maateenheid.Equals("inch"))
            {
                if (aantal < 0)
                {
                    Console.WriteLine("De waarde mag niet negatief zijn, het programma zal stoppen.");
                }
                else
                {
                    if (maateenheid.Equals("cm"))
                    {
                        uitkomst = aantal * 2.54;
                        Console.WriteLine("de lengte in cm is : " + uitkomst);
                    }
                    else
                    {
                        if (maateenheid.Equals("inch"))
                        {
                            uitkomst = aantal * 0.393;
                            Console.WriteLine("de lengte in inch is : " + uitkomst);
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Ongeldige invoer, het programma zal stoppen.");
            }
        }
    }
}
