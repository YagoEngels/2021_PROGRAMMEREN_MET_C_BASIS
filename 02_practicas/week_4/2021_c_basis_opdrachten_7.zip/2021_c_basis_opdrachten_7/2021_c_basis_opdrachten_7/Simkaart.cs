﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_7
{
    class Simkaart
    {
        private string telefoonNummer;
        private DateTime creatieDatum;

        public Simkaart() {
            telefoonNummer = string.Empty;
            creatieDatum = DateTime.Now;
        }

        public void setTelefoonNummer(string nummer)
        {
            telefoonNummer = nummer;
        }

        public string getTelefoonNummer()
        {
            return telefoonNummer;
        }

        public DateTime getCreatieDatum()
        {
            return creatieDatum;
        }

        public string getZin()
        {
            string uit = "+32 " + telefoonNummer + "/ Facturatie datum: " + creatieDatum.ToString();
            return uit;
        }
    }
}
