﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_7
{
    class Simbox
    {
        private Simkaart simkaart1;
        private Simkaart simkaart2;
        private Simkaart simkaart3;
        private int aantalSimKaarten;


        public Simbox()
        {

        }

        public void addSimKaart(string s)
        {
            if(s.Length != 0)
            {
                if (simkaart1 == null)
                {
                    simkaart1 = new Simkaart();
                    simkaart1.setTelefoonNummer(s);
                } else
                {
                    if (simkaart2 == null)
                    {
                        simkaart2 = new Simkaart();
                        simkaart2.setTelefoonNummer(s);
                    } else
                    {
                        if (simkaart3 == null)
                        {
                            simkaart3 = new Simkaart();
                            simkaart3.setTelefoonNummer(s);
                        }
                    }
                }
            }
        }

        public void getOverzicht()
        {
            if (simkaart1 != null && simkaart2 != null && simkaart3 != null)
            {
                Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:");
                Console.WriteLine("\t - SIM kaart 1:" + simkaart1.getZin());
                Console.WriteLine("\t - SIM kaart 2:" + simkaart2.getZin());
                Console.WriteLine("\t - SIM kaart 3:" + simkaart3.getZin() + "\n");
            }
            else
            {
                if(simkaart1 != null && simkaart2 != null && simkaart3 == null)
                {
                    Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:");
                    Console.WriteLine("\t - SIM kaart 1:" + simkaart1.getZin());
                    Console.WriteLine("\t - SIM kaart 2:" + simkaart2.getZin() + "\n");
                }
                else
                {
                    if(simkaart1 != null && simkaart2 == null && simkaart3 == null)
                    {
                        Console.WriteLine("\n \tOverzicht geinstalleerde sim kaarten:");
                        Console.WriteLine("\t - SIM kaart 1:" + simkaart1.getZin() + "\n");
                    }
                    else
                    {
                        Console.WriteLine("dees suckt");
                    }
                }
            }
        }

        public void getSim1()
        {
            Console.WriteLine(simkaart1.getZin());
            Console.WriteLine(simkaart2.getZin());
            Console.WriteLine(simkaart3.getZin());
        }

        public int getAantalSimKaarten()
        {
            int uit = 0;
            if(simkaart1 == null)
            {
                uit = 0;
            } else
            {
                if (simkaart1 != null && simkaart2 == null && simkaart3 == null)
                {
                    uit = 1;
                } else
                {
                    if (simkaart1 != null && simkaart2 != null && simkaart3 == null)
                    {
                        uit = 2;
                    } else
                    {
                        if (simkaart1 != null && simkaart2 != null && simkaart3 != null)
                        {
                            uit = 3;
                        }
                    }
                }
            }
            return uit;
        }
    }
}
