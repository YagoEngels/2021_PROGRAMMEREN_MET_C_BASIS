﻿using System;

namespace _2021_c_basis_opdrachten_7
{
    class Program
    {
        //int keuze 
        static int keuze = 0;
        static Simbox simbox = new Simbox();

        static void Main(string[] args)
        {


            menu();

        }
        static void menu()
        {
            Console.WriteLine("********************************************");
            Console.WriteLine("****************** SIMBOX ******************");
            Console.WriteLine("********************************************");
            Console.WriteLine("********************************************");
            Console.WriteLine("** 1 : Simkaart gegevens ingeven ***********");
            Console.WriteLine("** 2 : Overzicht SIM kaart gegevenbs *******");
            Console.WriteLine("** 3 : Aantal geinstalleerde sim kaarten ***");
            Console.WriteLine("** 4 : STOP ********************************");

            keuze = int.Parse(Console.ReadLine());

            Simkaart simkaart = new Simkaart();

            switch (keuze)
            {
                case 1:
                    if(simbox.getAantalSimKaarten() != 3)
                    {
                        Console.Write("geef het telefoonnummer van de simkaart in:   ");
                        string s = Console.ReadLine();
                        Console.WriteLine("");
                        simbox.addSimKaart(s);
                    } else
                    {
                        Console.WriteLine("Maximaal aantal SIM kaarten geinstalleerd \n");
                    }
                    menu();
                    break;

                case 2:
                    //simbox.getSim1();
                    simbox.getOverzicht();
                    menu();
                    break;

                case 3:
                    Console.WriteLine("Aantal geinstalleerde SIM kaarten :" + simbox.getAantalSimKaarten() + " (nog " +(3-simbox.getAantalSimKaarten()) +" slot(s) vrij) \n");
                    menu();
                    break;

                case 4:
                    Console.WriteLine("********************************************");
                    Console.WriteLine("***************--- by by ---****************");
                    Console.WriteLine("********************************************");
                    break;

            }
        }
    }
}
