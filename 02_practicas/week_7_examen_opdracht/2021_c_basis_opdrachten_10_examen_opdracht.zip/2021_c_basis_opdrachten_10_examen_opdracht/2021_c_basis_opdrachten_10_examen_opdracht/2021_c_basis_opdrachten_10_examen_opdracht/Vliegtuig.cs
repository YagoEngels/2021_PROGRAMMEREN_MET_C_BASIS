﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_10_examen_opdracht
{
    class Vliegtuig
    {
        private string Vluchtnummer;
        Baan baan;
        private enum VliegStatus
        {
            OpstijgenAanTeVragen = true,
            OpstijgenGoedGekeurd = false,
            Opgestegen = false
        }

        public string vluchtnummer
        {
            get
            {
                return Vluchtnummer;
            }
            set
            {
                if(value != null)
                {
                    Vluchtnummer = value;
                }
            }
        }

        public string vliegstatus
        {
            get
            {
                switch (true)
                {
                    case (Boolean)VliegStatus.OpstijgenAanTeVragen:
                        return VliegStatus.OpstijgenAanTeVragen;
                        break;

                    case (Boolean)VliegStatus.OpstijgenGoedGekeurd:
                        return VliegStatus.OpstijgenGoedGekeurd;
                        break;

                    case (Boolean)VliegStatus.Opgestegen:
                        return VliegStatus.Opgestegen;
                        break;
                }
            }

            set
            {
                if(value.Equals("OpStijgenAanTeVragen"))
                {
                  VliegStatus.OpstijgenAanTeVragen = true; 
                  VliegStatus.OpstijgenAanTeVragen = false; 
                  VliegStatus.OpstijgenAanTeVragen = false;
                }
                if (value.Equals("OpStijgenGoedGekeurd"))
                {
                    VliegStatus.OpstijgenAanTeVragen = false; 
                    VliegStatus.OpstijgenAanTeVragen = true; 
                    VliegStatus.OpstijgenAanTeVragen = false;
                }
                if (value.Equals("Opgestegen"))
                {
                    VliegStatus.OpstijgenAanTeVragen = false; 
                    VliegStatus.OpstijgenAanTeVragen = false; 
                    VliegStatus.OpstijgenAanTeVragen = true;
                }
            }
        }

        public Vliegtuig()
        {

        }
        public string StijgOp()
        {
            string uit = "";
            vliegstatus = "Opgestegen";
            baan.vrij = true;
            baan = null;
        }

        public string GeefOmschrijving()
        {
            string uit = "\t-\tVluchtnummer:\t" + vluchtnummer + "\t/\tStatus:\t" + vliegstatus + "\t/\tToegewezen baan:" + baan.naam;
            return uit;
        }
    }
}
