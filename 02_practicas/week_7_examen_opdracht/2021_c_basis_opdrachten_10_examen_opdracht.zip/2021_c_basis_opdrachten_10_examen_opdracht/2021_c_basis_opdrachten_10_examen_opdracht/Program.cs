﻿using System;

namespace _2021_c_basis_opdrachten_10_examen_opdracht
{
    class Program
    {
        static void Main(string[] args)
        {
            Baan baan = new Baan();

            Console.WriteLine(baan.GeefOmschrijving());
        }
    }
}
