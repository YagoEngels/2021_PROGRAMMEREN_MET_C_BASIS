﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_10_examen_opdracht
{
    class Baan
    {
        private string Code;
        private Boolean Vrij;

        public string code
        {
            get
            {
                return Code;
            }
            set
            {
                if(value != null)
                {
                    Code = value;
                }
            }
        }

        public Boolean vrij
        {
            get
            {
                return Vrij;
            }
            set
            {
                Vrij = value;
            }
        }

        public Baan()
        {
            string rand = "abcdefghijklmnopqrstuvwxyz123456789";
            string code2 = "";
            Random random = new Random();
            for(int i = 0; i < 5; i++)
            {
                code2 += rand.ElementAt(random.Next(rand.Count()));
            }
            code = code2;
            vrij = true;
        }


        public string GeefOmschrijving()
        {
            string uit = "";
            uit += "\t-\tCode:\t" + code + "\t/\tVrij:\t" + vrij;
            return uit;
        }
    }
}
