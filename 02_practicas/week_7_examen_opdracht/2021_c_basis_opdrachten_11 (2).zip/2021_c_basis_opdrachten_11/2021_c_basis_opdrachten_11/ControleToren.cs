﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_11
{
    class ControleToren
    {
        List<Vliegtuig> Vliegtuigs = new List<Vliegtuig>();
        List<Baan> Baans = new List<Baan>();

        public ControleToren()
        {

        }

        public string RegistreerVliegtuig(Vliegtuig vliegtuig)
        {
            string uit = "";
            string vluchtnummer2 = string.Empty;
            Random random = new Random();
            do
            {
                int asciinr = random.Next(48, 91);
                if (asciinr >= 58 && asciinr < 65)
                {
                    continue;
                }
                vluchtnummer2 += (char)asciinr;
            } while (vluchtnummer2.Length < 6);

            vliegtuig.vluchtnummer = vluchtnummer2;
            vliegtuig.vliegstatus = "OpStijgenAanTeVragen";

            uit += "Vliegtuig werd geregistreerd.\tvluchtnummer:\t" + vliegtuig.vluchtnummer;
            Vliegtuigs.Add(vliegtuig);
            return uit;
        }
    }
}
