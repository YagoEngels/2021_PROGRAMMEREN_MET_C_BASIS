﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_11
{
    class Vliegtuig
    {
        private string Vluchtnummer;
        Baan baan;
        List<bool> VliegStatus = new List<bool>() { true, false, false };

        public Baan baan1
        {
            get
            {
                return baan;
            }
            set
            { 
                baan = value;
            }
        }
        public string vluchtnummer
        {
            get
            {
                return Vluchtnummer;
            }
            set
            {
                if (value != null)
                {
                    Vluchtnummer = value;
                }
            }
        }

        public string vliegstatus
        {
            get
            {
                string uit = "";
                int index = 0;
                for(int i = 0; i < VliegStatus.Count; i++)
                {
                    if(VliegStatus[i] == true)
                    {
                        index = i;
                    }
                }

                switch (index)
                {
                    case 0:
                        uit = "OpstijgenAanTeVragen";
                        break;
                    case 1:
                        uit = "OpstijgenGoedGekeurd";
                        break;
                    case 2:
                        uit = "OpGestegen";
                        break;
                }
                return uit;
            }

            set
            {
                if (value.Equals("OpstijgenAanTeVragen"))
                {
                    VliegStatus[0] = true;
                    VliegStatus[1] = false;
                    VliegStatus[2] = false;
                }
                if (value.Equals("OpstijgenGoedGekeurd"))
                {
                    VliegStatus[0] = false;
                    VliegStatus[1] = true;
                    VliegStatus[2] = false;
                }
                if (value.Equals("OpGestegen"))
                {
                    VliegStatus[0] = false;
                    VliegStatus[1] = false;
                    VliegStatus[2] = true;
                }
            }
        }

        public Vliegtuig()
        {

        }
        public string StijgOp()
        {
            string uit = "";
            vliegstatus = "Opgestegen";
            baan.vrij = true;
            baan = null;
            return uit;
        }

        public string GeefOmschrijving()
        {
            string baanCode = "null";
            if(baan1 != null)
            {
                baanCode = baan1.code;
            }
            string uit = "\t-\tVluchtnummer:\t" + vluchtnummer + "\t/\tStatus:\t" + vliegstatus + "\t/\tToegewezen baan:" + baanCode;
            return uit;
        }
    }
}
