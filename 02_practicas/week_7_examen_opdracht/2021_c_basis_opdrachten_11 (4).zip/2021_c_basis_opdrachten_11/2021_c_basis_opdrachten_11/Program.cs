﻿using System;

namespace _2021_c_basis_opdrachten_11
{
    class Program
    {
        static ControleToren controle = new ControleToren();
        static int keuze = 0;

        static void Main(string[] args)
        {
            menu();
        }
        static void menu()
        {
            Console.WriteLine("Controletoren\t-\tmenu:");
            Console.WriteLine("1.\tVoeg baan toe.");
            Console.WriteLine("2.\tRegistreer vliegtuig.");
            Console.WriteLine("3.\tControletoren overzicht.");
            Console.WriteLine("4.\tAanvraag voor opstijgen");
            Console.WriteLine("5.\tOpstijgen");
            Console.WriteLine("6.\tStop");

            keuze = int.Parse(Console.ReadLine());

            switch (keuze)
            {
                case 1:
                    Console.Write("Geef de baan code in :");
                    controle.RegistreerBaan(new Baan(Console.ReadLine()));
                    Console.WriteLine(controle.OverzichtBanen());
                    Console.Write("druk op enter om door te gaan");
                    Console.ReadLine();
                    Console.Clear();
                    menu();
                    break;

                case 2:
                    controle.RegistreerVliegtuig(new Vliegtuig());
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    Console.Write("druk op enter om door te gaan");
                    Console.ReadLine();
                    Console.Clear();
                    menu();
                    break;

                case 3:
                    Console.WriteLine(controle.OverzichtBanen());
                    if (controle.countBanen() == 0)
                    {
                        Console.WriteLine("Er is nog geen baan toegevoegd");
                    }
                    Console.WriteLine();
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    if (controle.countVliegtuigen() == 0)
                    {
                        Console.WriteLine("Er is nog geen vliegtuig toegevoegd");
                    }
                    Console.Write("druk op enter om door te gaan");
                    Console.ReadLine();
                    Console.Clear();
                    menu();
                    break;

                case 4:
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    if (controle.countVliegtuigen() == 0)
                    {
                        Console.WriteLine("Er is nog geen vliegtuig toegevoegd");
                    }
                    Console.Write("Geef het vluchtnummer\t:\t");
                    Console.WriteLine(controle.AanvraagTotOptstijgen(Console.ReadLine()));
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    if (controle.countVliegtuigen() == 0)
                    {
                        Console.WriteLine("Er is nog geen vliegtuig toegevoegd");
                    }
                    Console.Write("druk op enter om door te gaan");
                    Console.ReadLine();
                    Console.Clear();
                    menu();
                    break;
                case 5:
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    if (controle.countVliegtuigen() == 0)
                    {
                        Console.WriteLine("Er is nog geen vliegtuig toegevoegd");
                    }
                    Console.Write("Geef het vluchtnummer\t:\t");
                    Console.WriteLine(controle.Opstijgen(Console.ReadLine()));
                    Console.WriteLine(controle.OverzichtVliegtuigen());
                    if (controle.countVliegtuigen() == 0)
                    {
                        Console.WriteLine("Er is nog geen vliegtuig toegevoegd");
                    }
                    Console.Write("druk op enter om door te gaan");
                    Console.ReadLine();
                    Console.Clear();
                    menu();
                    break;
                case 6:
                    Console.WriteLine("by by");
                    break;

            }
        }
    }
}
