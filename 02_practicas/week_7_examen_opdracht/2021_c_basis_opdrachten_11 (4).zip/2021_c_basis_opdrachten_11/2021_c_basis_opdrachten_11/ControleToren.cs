﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_opdrachten_11
{
    class ControleToren
    {
        List<Vliegtuig> Vliegtuigen = new List<Vliegtuig>();
        List<Baan> Baanen = new List<Baan>();

        public ControleToren()
        {

        }
        public void RegistreerBaan(Baan baan)
        {
            if(baan != null)
            {
                Baanen.Add(baan);
            }
        }

        public string RegistreerVliegtuig(Vliegtuig vliegtuig)
        {
            string uit = "";
            string vluchtnummer2 = string.Empty;
            Random random = new Random();
            do
            {
                int asciinr = random.Next(48, 91);
                if (asciinr >= 58 && asciinr < 65)
                {
                    continue;
                }
                vluchtnummer2 += (char)asciinr;
            } while (vluchtnummer2.Length < 6);

            vliegtuig.vluchtnummer = vluchtnummer2;
            vliegtuig.vliegstatus = "OpStijgenAanTeVragen";

            uit += "Vliegtuig werd geregistreerd.\tvluchtnummer:\t" + vliegtuig.vluchtnummer;
            Vliegtuigen.Add(vliegtuig);
            return uit;
        }

        public Vliegtuig ZoekVliegtuig(string Vluchtnummer)
        {
            Vliegtuig uit = null;
            foreach(Vliegtuig v in Vliegtuigen)
            {
                if(Vluchtnummer == v.vluchtnummer)
                {
                    uit = v;
                }
            }
            return uit;
        }

        public string AanvraagTotOptstijgen(string Vluchtnummer)
        {
            string uit = "";
            Vliegtuig v = ZoekVliegtuig(Vluchtnummer);
            if(v != null)
            {
                if (v.vliegstatus.Equals("OpstijgenAanTeVragen"))
                {
                    if(ZoekVrijeBaan() != null)
                    {
                        v.baan1 = ZoekVrijeBaan();
                        v.baan1.vrij = false;
                        v.vliegstatus = "OpstijgenGoedGekeurd";
                        uit = "Opstijgen toegelaten\t-\tToegewezen aan baan " + v.baan1.code;
                    }
                    else
                    {
                        uit = "Geen toelating\t-\tGeen enkele baan is vrij";
                    }
                } else
                {
                    uit = "Geen toelating\t-\tStatus vliegtuig niet overeenkomstig: OpStijgenGoedGekeurd";
                }
            } 
            else
            {
                uit = "Geen toelating\t-\tDit vliegtuig bestaat niet"; 
            }
            return uit;
        }
        public string Opstijgen(string Vluchtnummer)
        {
            string uit = "";
            Vliegtuig v = ZoekVliegtuig(Vluchtnummer);
            if(v != null)
            {
                if (v.vliegstatus.Equals("OpstijgenGoedGekeurd"))
                {
                    uit = "Vlucht met vluchtnummer + " + Vluchtnummer + " is opgestegen op baan " + v.baan1.code;
                    v.vliegstatus = "OpGestegen";
                    v.baan1.vrij = true;
                } 
                else
                {
                    uit = "Geen toelating\t-\tStatus vliegtuig niet overeenkomstig: OpStijgenGoedGekeurd";
                }
            } 
            else
            {
                uit = "Geen toelating\t-\tDit vliegtuig bestaat niet"; 
            }
            return uit;
        }
        public Baan ZoekVrijeBaan()
        {
            Baan uit = null;
            foreach(Baan b in Baanen)
            {
                if (b.vrij)
                {
                    uit = b;
                }
            }
            return uit;
        }

        public string OverzichtVliegtuigen()
        {
            string uit = "Overzicht vliegtuigen:\n";
            foreach(Vliegtuig v in Vliegtuigen)
            {
                uit += v.GeefOmschrijving() + "\n";
            }
            return uit;
        }

        public string OverzichtBanen()
        {
            string uit = "Overzicht banen:\n";
            foreach (Baan b in Baanen)
            {
                uit += b.GeefOmschrijving() + "\n";
            }
            return uit;
        }

        public int countVliegtuigen()
        {
            int uit = 0;
            uit = Vliegtuigen.Count;
            return uit;
        }
        public int countBanen()
        {
            int uit = 0;
            uit = Baanen.Count;
            return uit;
        }
    }
}
