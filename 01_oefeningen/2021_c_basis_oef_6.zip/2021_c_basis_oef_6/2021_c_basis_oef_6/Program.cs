﻿using System;

namespace _2021_c_basis_oef_6
{
    class Program
    {
        static int aantal;
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Hello World!");
            Wiskunde w = new Wiskunde(5, 3);
            Console.WriteLine(w.Opsomming());
            Console.WriteLine(w.Aftrekking());
            Console.WriteLine(w.maal());
            Console.WriteLine(w.deling());
            */

            menu();

            static void menu()
            {
                //variabelen
                string keuze = "";

                Console.WriteLine("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                Console.WriteLine("@ MENU \t \t \t \t \t \t@");
                Console.WriteLine("@ ==== \t \t \t \t \t \t@");
                Console.WriteLine("@ a: bereken oppervlakte cirkel \t \t@");
                Console.WriteLine("@ b: bereken oppervlakte vierkant \t \t@");
                Console.WriteLine("@ c: bereken oppervlakte cilinder \t \t@");
                Console.WriteLine("@ d: bereken omtrek cirkel \t \t \t@");
                Console.WriteLine("@ e: bereken omtrek vierkant \t \t \t@");
                Console.WriteLine("@ f: bereken omtrek cilinder \t \t \t@");
                Console.WriteLine("@ g: print het aantal functie oproepingen \t@");
                Console.WriteLine("@ h: exit \t \t \t \t \t@");
                Console.Write("@ Maak je keuze : ");

                keuze = Console.ReadLine();

                if (keuze.Equals("a"))
                {
                    a();
                }
                if (keuze.Equals("b"))
                {
                    b();
                }
                if (keuze.Equals("c"))
                {
                    c();
                }
                if (keuze.Equals("d"))
                {
                    d();
                }
                if (keuze.Equals("e"))
                {
                    e();
                }
                if (keuze.Equals("f"))
                {
                    f();
                }
                if (keuze.Equals("g"))
                {
                    g();
                }
                if (keuze.Equals("h"))
                {
                    h();
                }
            }

            static void a()
            {
                double straal;
                Console.Write("@ Wat is de straal : ");
                straal = double.Parse(Console.ReadLine());
                Oppervlakte oppervlakte = new Oppervlakte();
                Console.WriteLine("\n############################# \n" + "De oppervlakkte is " + oppervlakte.a(straal) + "\n############################# \n");
                aantal++;
                menu();
            }
            static void b()
            {
                double lengte;
                double breedte;
                Console.Write("@ Wat is de lengte : ");
                lengte = double.Parse(Console.ReadLine());
                Console.Write("@ Wat is de breedte : ");
                breedte = double.Parse(Console.ReadLine());
                Oppervlakte oppervlakte = new Oppervlakte();
                Console.WriteLine("\n############################# \n" + "De oppervlakkte is " + oppervlakte.b(breedte,lengte) + "\n############################# \n");
                aantal++;
                menu();
            }
            static void c()
            {
                double straal;
                double hoogt;
                Console.Write("@ Wat is de straal : ");
                straal = double.Parse(Console.ReadLine());
                Console.Write("@ Wat is de hoogte : ");
                hoogt = double.Parse(Console.ReadLine());
                Oppervlakte oppervlakte = new Oppervlakte();
                Console.WriteLine("\n############################# \n" + "De oppervlakkte is " + oppervlakte.c(straal,hoogt) + "\n############################# \n");
                aantal++;
                menu();
            }

            static void d()
            {
                double diameter;
                Console.Write("@ Wat is de diameter : ");
                diameter = double.Parse(Console.ReadLine());
                Omtrek omtrek = new Omtrek();
                Console.WriteLine("\n############################# \n" + "De omtrek is " + omtrek.d(diameter) + "\n############################# \n");
                aantal++;
                menu();
            }
            static void e()
            {
                double breedte;
                double lengte;
                Console.Write("@ Wat is de breedte : ");
                breedte = double.Parse(Console.ReadLine());
                Console.Write("@ Wat is de lengte : ");
                lengte = double.Parse(Console.ReadLine());
                Omtrek omtrek = new Omtrek();
                Console.WriteLine("\n############################# \n" + "De omtrek is " + omtrek.e(breedte , lengte) + "\n############################# \n");
                aantal++;
                menu();
            }
            static void f()
            {
                double straal;
                double hoogte;
                Console.Write("@ Wat is de straal : ");
                straal = double.Parse(Console.ReadLine());
                Console.Write("@ Wat is de hoogte : ");
                hoogte = double.Parse(Console.ReadLine());
                Omtrek omtrek = new Omtrek();
                Console.WriteLine("\n############################# \n"+"De omtrek is " + omtrek.f(straal , hoogte) + "\n############################# \n");
                aantal++;
                menu();
            }
            static void g()
            {
                Console.WriteLine("\n############################# \n het aantal opgeroepen functies is :" + aantal+"\n############################# \n" );
                menu();
            }
            static void h()
            {
                Console.WriteLine("\n############################# \n" + "by by"+"\n############################# \n");
            }
        }
    }
}
