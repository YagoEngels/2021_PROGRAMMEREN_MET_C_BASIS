﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_oef_6
{
    class Wiskunde
    {
        int eerste;
        int tweede;

        public Wiskunde(int a , int b)
        {
            eerste = a;
            tweede = b;
        }
        
        public int Opsomming()
        {
            int uit = eerste + tweede;
            return uit;
        }

        public int Aftrekking()
        {
            int uit = eerste - tweede;
            return uit;
        }

        public int maal()
        {
            int uit = eerste * tweede;
            return uit;
        }

        public double deling()
        {
            double uit = eerste / tweede;
            return uit;
        }
    }
    
}
