﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_oef_6
{
    class Oppervlakte
    {
        double pi = 3.14;
        double straal;
        double breedte;
        double lengte;
        double height;

        public Oppervlakte()
        {
        }

        public double a(double a)
        {
            straal = a;
            double uit;
            uit = pi * (straal * straal);
            return uit;
        }
        public double b(double a , double b)
        {
            breedte = a;
            lengte = b;
            double uit;
            uit = breedte * lengte;
            return uit;
        }
        public double c(double a, double b)
        {
            straal = a;
            height = b;
            double uit;
            uit = pi * (straal * straal);
            uit += uit;
            uit += (2 * pi * straal * height);
            return uit;
        }
    }
}
