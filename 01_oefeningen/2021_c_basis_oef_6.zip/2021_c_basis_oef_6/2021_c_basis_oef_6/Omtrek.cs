﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_oef_6
{
    class Omtrek
    {
        double pi = 3.14;
        double diameter;
        double lengte;
        double breedte;
        double straal;
        double hoogte;

        public Omtrek()
        {

        }
        public double d(double a)
        {
            diameter = a;
            double uit;
            uit = pi * diameter;
            return uit;
        }
        public double e(double a, double b)
        {
            breedte = a;
            lengte = b;
            double uit;
            uit = breedte + breedte + lengte + lengte;
            return uit;
        }
        public double f(double a, double b)
        {
            straal = a;
            hoogte = b;
            double uit;
            uit = d(straal * 2) * hoogte;
            return uit;
        }
    }
}
