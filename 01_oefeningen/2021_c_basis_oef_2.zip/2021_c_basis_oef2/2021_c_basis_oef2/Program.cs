﻿using System;

namespace _2021_c_basis_oef2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("\\\\server\\technotes\\names.txt");
            //Console.WriteLine(@"\\server\technotes\names.txt");

            //oefening 2
            /*
            Console.WriteLine("geef u naam hier  :");
            string x = Console.ReadLine();
            Console.WriteLine(x);
            */

            //oefening 3
            /*Console.WriteLine("geef uw leeftijd");
            string leeftijd = Console.ReadLine();
            int leeftijdInt = int.Parse(leeftijd);

            Console.WriteLine("je bent " + leeftijdInt + "jaar oud");
            */

            //oefening 4
            /*Console.Write("Geef je naam in: ");
            string x = Console.ReadLine();
            //Console.WriteLine(x);

            Console.WriteLine("\nhallo " + x);

            Console.Write(" \n            Geef je leeftijd un uitgedrukt in jaren: ");
            int y = int.Parse(Console.ReadLine());
            //Console.WriteLine(y);

            int z = 18 - y;
            Console.WriteLine("\nbinnen " + z + " jaren word je volwassen");
            */

            //oefening 5
            /*
            Console.Write("Geef je leeftijd:");
            int leeftijd = int.Parse(Console.ReadLine());
            bool booleanLeeftijd = leeftijd < 18 || leeftijd > 65;
            Console.WriteLine("\n Korting door leeftijd < 18 of > 65: " + booleanLeeftijd);
            */

            //oefening 6
            //-lees een waarde en converteer deze naar een int en print deze af
            //-lees een waarde en voncerteer deze naar een long en print deze af
            //-lees een wsaarde en converteer deze naar een float en print deze af
            //-lees een waarde en converteer deze naar een double en print deze af
            //-lees een waarde en converteer deze naar een decimal en print deze af
            //-lees een waarde en converteer deze naar een char en print deze af

            /*Console.Write("geef mij een waarde:");
            string waarde = Console.ReadLine();

            //1
            Console.WriteLine(int.Parse(waarde));
            //2
            Console.WriteLine(long.Parse(waarde));
            //3
            Console.WriteLine(float.Parse(waarde));
            //4
            Console.WriteLine(double.Parse(waarde));
            //5
            Console.WriteLine(decimal.Parse(waarde));
            //6
            Console.WriteLine(char.Parse(waarde));*/

            //oefening 7
            // - bereken een int en een double samen en steek deze in een int variable
            // - bereken een int en een oduble samen en steek deze in een double variable
            // - bereken een lfoat en een oduble samen en steek deze in een float vartialbele


            //1
            Console.Write("geef mij een int :");
            int a1 = int.Parse(Console.ReadLine());
            Console.Write("geef mij een double :");
            double b1 = double.Parse(Console.ReadLine());
            Console.WriteLine("int = int + double");
            int c1 = a1 + (int)b1;
            Console.WriteLine(c1);

            //2
            Console.Write("geef mij een double :");
            double a2 = double.Parse(Console.ReadLine());
            Console.Write("geef mij een int :");
            int b2 = int.Parse(Console.ReadLine());
            Console.WriteLine("double = int + double");
            double c2 = a2 + b2;
            Console.WriteLine(c2);

            //3
            Console.Write("geef mij een float :");
            float a3 = int.Parse(Console.ReadLine());
            Console.Write("geef mij een double :");
            double b3 = double.Parse(Console.ReadLine());
            Console.WriteLine("float = float + double");
            float c3 = a3 + (float)b3;
            Console.WriteLine(c3);
        }
    }
}
