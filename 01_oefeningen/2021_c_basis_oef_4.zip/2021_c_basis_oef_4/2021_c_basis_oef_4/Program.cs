﻿using System;

namespace _2021_c_basis_oef_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int leeftijd = 10;
            /*
            if (leeftijd > 18)
            {
                Console.WriteLine("je bent meerderjarig");
                if (leeftijd > 60)
                {
                    Console.WriteLine("je bent extra meerderjarig");
                }
            } else if( leeftijd == 16)
            {
                Console.WriteLine("je bent 16 ");
            } else
            {
                Console.WriteLine("je bent niet meerderjarig");
            }
            */

            /*
            switch (leeftijd)
            {
                case 1:
                    Console.WriteLine("ik ben 1 jaar oud");
                    break;
                case 2:
                    Console.WriteLine("ik ben 2 jaar oud");
                    break;
                case 10:
                    Console.WriteLine("ik ben 10 jaar oud");
                    break;
            }
            */

            /*Console.WriteLine("score op 5 : ");
            int score = int.Parse(Console.ReadLine());

            Console.WriteLine("gedelibereerd : true/false");
            bool gedelebereerd = bool.Parse(Console.ReadLine());

            switch (score)
            {
                case 0:
                case 1:
                    Console.WriteLine("onvoldoende");
                    break;
                case 2:
                    if(score == 2 && gedelebereerd)
                    {
                        Console.WriteLine("geslaagd");
                    } else
                    {
                        Console.WriteLine("onvoldoende");
                    }
                    break;
                case 3:
                case 4:
                    Console.WriteLine("geslaafd");
                    break;
                case 5:
                    Console.WriteLine("met grote onderscheiding geslaagd");
                    break;
                default:
                    Console.WriteLine("geen correcte invoer");
                    break;
            }
            */

            Console.WriteLine("geef je wachtwoord");
            string password = "";
            while (true)
            {
                Console.WriteLine("Geef je wachtwoord");
            }
        }
    }
}
