﻿using System;

namespace _2021_c_basis_oef_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //oefening 1
            /*
            int getal1 = 10;
            int getal2 = 20;

            double result = getal1 + ((double)getal1/ getal2);
            Console.WriteLine(result);
            */

            //oefening 2
            /*
            double getal1 = 5;
            int getal2 = 20;

            double result = getal1 + ((int)getal1 / getal2);
            Console.WriteLine(result);
            */

            //oefening 3
            /*
            double getal1 = 5;
            int getal2 = 20;

            float result = (float)getal1 + getal2;
            Console.WriteLine(result);
            */

            //oefening 4
            /*
            double getal1 = 5;
            float getal2 = 20;

            long result = (long)(getal1 + (getal1 /getal2));
            Console.WriteLine(result);
            */

            //oefening 5
            /*
            double getal1 = 5;
            int getal2 = 20;

            float result = (float)(getal1 + (getal1 / getal2));
            Console.WriteLine(result);
            */

            // wiskunde oefening 1
            /*
            int getal1 = 10;
            int getal2 = 25;

            int result =getal2  getal1;
            Console.WriteLine(result);
            */

            // wiskunde oefening 2
            /*
            int getal1 = 10;
            int getal2 = 25;

            int result = ++getal2 + getal1;
            Console.WriteLine(result);
            */

            //wiskunde oefening 3
            /*
            int getal1 = 10;
            int getal2 = 25;

            int result = ++getal2 + --getal1;
            Console.WriteLine(result);
            */

            // toekeninngsoperatoren oefening 1
            /*
            int getal1 = 10;
            int getal2 = 25;

            getal2 += getal1;
            Console.WriteLine(getal2);
            */

            // toekeninngsoperatoren oefening 2
            /*
            int getal1 = 10;
            int getal2 = 25;

            getal2 /= getal1;
            Console.WriteLine(getal2);
            */

            // toekeninngsoperatoren oefening 3
            /*
            int getal1 = 10;
            int getal2 = 25;

            getal2 %= getal1;
            Console.WriteLine(getal2);
            */

            // relationele oefening 1
            /*
            int getal1 = 10;
            int getal2 = 25;

            bool result = getal2 > getal1;
            Console.WriteLine(result);
            */

            // relationele oefening 2
            /*
            int getal1 = 10;
            int getal2 = 25;

            bool result = getal2 < getal1;
            Console.WriteLine(result);
            */

            // relationele oefening 3
            /*
            int getal1 = 10;
            int getal2 = 25;

            bool result = getal2 >= getal1 == getal2 <= getal1;
            Console.WriteLine(result);
            */

            // relationele oefening 4
            /*
            int getal1 = 10;
            int getal2 = 25;

            bool result = getal2 >= getal1 != getal2 <= getal1;
            Console.WriteLine(result);
            */

            // relationele oefening 5
            /*
            int getal1 = 10;
            int getal2 = 25;

            bool result = getal2 == getal1;
            Console.WriteLine(result);
            */
        }
    }
}
