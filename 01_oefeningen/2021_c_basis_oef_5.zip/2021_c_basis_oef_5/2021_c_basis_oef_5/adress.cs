﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_oef_5
{
    class Adress
    {
        private string gemeente;
        private int postcode;
        private string straat;
        private int nummer;

        public Adress(string g, int p , string s, int n)
        {
            Gemeente = g;
            Postcode = p;
            Straat = s;
            Nummer = n;
        }

        public string Gemeente
        {
            get
            {
                return gemeente;
            }
            set
            {
                if (value != null)
                {
                    gemeente = value;
                }
                else
                {
                    Console.WriteLine("Gegevensfout bij de gemeentesnaam");
                }
            }
        }

        public int Postcode
        {
            get
            {
                return postcode;
            }
            set
            {
                if (value != 0)
                {
                    postcode = value;
                }
                else
                {
                    Console.WriteLine("Gegevensfout bij de postcode");
                }
            }
        }

        public string Straat
        {
            get
            {
                return straat;
            }
            set
            {
                if (value != null)
                {
                    straat = value;
                } else
                {
                    Console.WriteLine("Gegevensfout bij het straatnaam");
                }
            }
        }

        public int Nummer
        {
            get
            {
                return nummer;
            }
            set
            {
                if (value != 0)
                {
                    nummer = value;
                } else
                {
                    Console.WriteLine("Gegevensfout bij het straatnummer");
                }
            }
        }
    }
}
