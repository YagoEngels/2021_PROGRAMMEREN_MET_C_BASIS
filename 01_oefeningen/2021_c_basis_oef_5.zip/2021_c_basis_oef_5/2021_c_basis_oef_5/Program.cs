﻿using System;

namespace _2021_c_basis_oef_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int leeftijd;
            string naam;
            string gemeente;
            int postcode;
            string straat;
            int nummer;
            string top = "*********************";

            Console.WriteLine("Hello World!");
            Console.Write("geef mij u leeftijd ");
            leeftijd = int.Parse(Console.ReadLine());

            Console.Write("geef mij u naam ");
            naam = Console.ReadLine();

            Console.Write("geef mij u gemeente ");
            gemeente = Console.ReadLine();

            Console.Write("geef mij u postcode ");
            postcode = int.Parse(Console.ReadLine());

            Console.Write("geef mij u straat ");
            straat = Console.ReadLine();

            Console.Write("geef mij u nummer ");
            nummer = int.Parse(Console.ReadLine());

            Adress adr = new Adress(gemeente, postcode, straat,nummer);
            Persoon per = new Persoon(leeftijd, naam, adr);
            Console.WriteLine(top + top + top + top);
            Console.WriteLine(top + "\t naam : "+per.Naam);
            Console.WriteLine(top + "\t leeftijd : " + per.Leeftijd);
            Console.WriteLine(top + top);
            Console.WriteLine(top + "\t straat : " + per.Adress.Straat);
            Console.WriteLine(top + "\t nummer : " + per.Adress.Nummer);
            Console.WriteLine(top + "\t gemeente : " + per.Adress.Gemeente);
            Console.WriteLine(top + "\t postcode : " + per.Adress.Postcode);
            Console.WriteLine(top + top + top + top);

        }
    }
}
