﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_basis_oef_5
{
    class Persoon
    {
        private int leeftijd;
        private string naam;
        private Adress adres;
        

        public Persoon(int l , string n , Adress ad)
        {
            Leeftijd = l;
            Naam = n;
            Adress = ad;
        }

        public int Leeftijd
        {
            get
            {
                return leeftijd;
            }
            set
            {
                if(value < 130 && value > 0)
                {
                    leeftijd = value;
                } else
                {
                    leeftijd = 1;
                    Console.WriteLine("Gegevensfout bij de leeftijd en daarom krijg jij de leeftijd 1 \n");
                }
            }
        }

        public string Naam
        {
            get
            {
                return naam;
            }
            set
            {
                if (value != null)
                {
                    naam = value;
                }
                else
                {
                    Console.WriteLine("Gegevensfout bij de naam");
                }
            }
        }

        public Adress Adress
        {
            get
            {
                return adres;
            }
            set
            {
                adres = value;
            }
        }

    }
}
